package me.lousy.lousyspawn;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

class LousySpawn extends JavaPlugin {
    private Location spawnLocation;

    @Override
    public void onEnable() {
        // Load spawn location from config (if set)
        if (getConfig().contains("spawn.x")) {
            double x = getConfig().getDouble("spawn.x");
            double y = getConfig().getDouble("spawn.y");
            double z = getConfig().getDouble("spawn.z");
            float yaw = (float) getConfig().getDouble("spawn.yaw");
            float pitch = (float) getConfig().getDouble("spawn.pitch");
            spawnLocation = new Location(getServer().getWorld(getConfig().getString("spawn.world")), x, y, z, yaw, pitch);
        }
    }

    @Override
    public void onDisable() {
        // Save spawn location to config
        if (spawnLocation != null) {
            getConfig().set("spawn.world", spawnLocation.getWorld().getName());
            getConfig().set("spawn.x", spawnLocation.getX());
            getConfig().set("spawn.y", spawnLocation.getY());
            getConfig().set("spawn.z", spawnLocation.getZ());
            getConfig().set("spawn.yaw", spawnLocation.getYaw());
            getConfig().set("spawn.pitch", spawnLocation.getPitch());
            saveConfig();
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("setspawn") && sender instanceof Player && sender.isOp()) {
            Player player = (Player) sender;
            spawnLocation = player.getLocation();
            player.sendMessage("Spawn location set!");
            return true;
        } else if (label.equalsIgnoreCase("spawn") && sender instanceof Player) {
            Player player = (Player) sender;
            if (spawnLocation != null) {
                player.teleport(spawnLocation);
                player.sendMessage("Teleported to spawn!");
            } else {
                player.sendMessage("Spawn location is not set!");
            }
            return true;
        }
        return false;
    }
}
